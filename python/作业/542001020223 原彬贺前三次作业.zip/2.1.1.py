c=3+4j;
print(c+c)
print(c**2)
print(c.real)
print(c.imag)
print(3+4j.imag)
print(c.conjugate())
print(abs(c))

import matplotlib.pyplot as plt
