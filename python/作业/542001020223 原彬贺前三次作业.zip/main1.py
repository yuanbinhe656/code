import math
print(math.factorial(32))
print(0.4-0.3==0.1)
print(math.isclose(0.4-0.3,0.1))
num=7
squreRoot=num**0.5
print(squreRoot**2==num)
print(math.isclose(squreRoot**2,num))