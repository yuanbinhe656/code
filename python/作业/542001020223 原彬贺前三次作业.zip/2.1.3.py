text = '''Beautiful is better than ugly.
Explicit is better than implicit.
Simple is better than complex.
Complex is better than complicated.
Flat is better than nested.
Sparse is better than dense.
Readability counts.'''
print(len(text))
print(text.count('is'))
print('beautiful' in text)
print('='*20)
print('Good'+'Morning')
import matplotlib.pyplot as plt
